var context = window;

(function() {
    
    var origWidth = null,
        origHeight = null,
        testDiv = null;

    /**
     * This function waits until all specified font-families loaded and rendered and then executes the callback function.
     * It doesn't add font-families to the document, all font-families should be added to the document elsewhere.
     * If after specific threshold time fonts won't be loaded, the callback function will be invoked with an error.
     * 
     * The callback function is invoked with a single error parameter.
     * If all fonts were loaded then this parameter will be null. Otherwise, object with message in the "message" field
     * and array in "notLoadedFontFamilies" field with all not loaded font-families will be returned.
     * 
     * @param {Array}    fontFamiliesArray   Array of font-families to load
     * @param {Function} fontsLoadedCallback Callback function to call after all font-families loaded
     * @param {Object}   [options]           Optional object with "maxNumOfTries" and "tryIntervalMs" properties.
     * @return {Object}
     */
    this.onFontsLoad = function onFontsLoad(fontFamiliesArray, fontsLoadedCallback, options) {
        var testContainer, clonedDiv,
            notLoadedFontFamilies = [],
            referenceFontFamily = "serif",
            i, interval,
            callbackParameter,
            tryCount = 0,
            maxNumOfTries = 50,
            tryIntervalMs = 50;
        
        function testDivDimensions() {
            var i, testDiv;
            for (i = testContainer.childNodes.length - 1; i >= 0; i--) {
                testDiv = testContainer.childNodes[i];
                if (testDiv.offsetWidth !== origWidth || testDiv.offsetHeight !== origHeight) {
                    // Div's dimensions changed, this means its font loaded, remove it from testContainer div
                    testDiv.parentNode.removeChild(testDiv);
                }
            }
        }
        
        function finish() {
            var testDiv;
            window.clearInterval(interval);
            testContainer.parentNode.removeChild(testContainer);
            if (testContainer.childNodes.length !== 0) {
                for (i = testContainer.childNodes.length - 1; i >= 0; i--) {
                    testDiv = testContainer.childNodes[i];
                    notLoadedFontFamilies.push(testDiv._ff);
                }
                callbackParameter = {
                    message: "Not all fonts are loaded",
                    notLoadedFontFamilies: notLoadedFontFamilies
                };
            } else {
                callbackParameter = null;
            }
            fontsLoadedCallback(callbackParameter);
        }
        
        if (options !== undefined) {
            if (options.maxNumOfTries) {
                maxNumOfTries = options.maxNumOfTries;
            }
            if (options.tryIntervalMs) {
                tryIntervalMs = options.tryIntervalMs;
            }
        }
        
        // Use pretty big fonts "40px" so smallest difference between standard
        // "serif" fonts and tested font-family will be noticable.
        testContainer = document.createElement("div");
        testContainer.style.cssText = "position:absolute; left:-10000px; top:-10000px; font-family: " + referenceFontFamily + "; font-size:40px;"; 
        document.body.appendChild(testContainer);
        
        if (testDiv === null) {
            testDiv = document.createElement("div");
            testDiv.style.position = "absolute";
            testDiv.style.whiteSpace = "nowrap";
            testDiv.appendChild(document.createTextNode(" !\"\\#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~Â¡Â¢Â£Â¤Â¥Â¦Â§Â¨Â©ÂªÂ«Â¬Â­Â®Â¯Â°Â±Â²Â³Â´ÂµÂ¶Â·Â¸Â¹ÂºÂ»Â¼Â½Â¾Â¿Ã€ÃÃ‚ÃƒÃ„Ã…Ã†Ã‡ÃˆÃ‰ÃŠÃ‹ÃŒÃÃŽÃÃÃ‘Ã’Ã“Ã”Ã•Ã–Ã—Ã˜Ã™ÃšÃ›ÃœÃÃžÃŸÃ Ã¡Ã¢Ã£Ã¤Ã¥Ã¦Ã§Ã¨Ã©ÃªÃ«Ã¬Ã­Ã®Ã¯Ã°Ã±Ã²Ã³Ã´ÃµÃ¶Ã·Ã¸Ã¹ÃºÃ»Ã¼Ã½Ã¾Ã¿Å’Å“Å Å¡Å¸Æ’Ë†ËœÎ‘Î’Î“Î”Î•Î–Î—Î˜Î™ÎšÎ›ÎœÎÎžÎŸÎ Î¡Î£Î¤Î¥Î¦Î§Î¨Î©Î±Î²Î³Î´ÎµÎ¶Î·Î¸Î¹ÎºÎ»Î¼Î½Î¾Î¿Ï€ÏÏ‚ÏƒÏ„Ï…Ï†Ï‡ÏˆÏ‰Ï‘Ï’Ï–â€“â€”â€˜â€™â€šâ€œâ€â€žâ€ â€¡â€¢â€¦â€°â€²â€³â€¹â€ºâ€¾â„â‚¬â„‘â„˜â„œâ„¢â„µâ†â†‘â†’â†“â†”â†µâ‡â‡‘â‡’â‡“â‡”âˆ€âˆ‚âˆƒâˆ…âˆ‡âˆˆâˆ‰âˆ‹âˆâˆ‘âˆ’âˆ—âˆšâˆâˆžâˆ âˆ§âˆ¨âˆ©âˆªâˆ«âˆ´âˆ¼â‰…â‰ˆâ‰ â‰¡â‰¤â‰¥âŠ‚âŠƒâŠ„âŠ†âŠ‡âŠ•âŠ—âŠ¥â‹…âŒˆâŒ‰âŒŠâŒ‹ã€ˆã€‰â—Šâ™ â™£â™¥â™¦"));
            
            // Get default dimensions
            testContainer.appendChild(testDiv);
            origWidth = testDiv.offsetWidth;
            origHeight = testDiv.offsetHeight;
            testDiv.parentNode.removeChild(testDiv);
        }
        
        // Add div for each font-family
        for (i = 0; i < fontFamiliesArray.length; i++) {
            clonedDiv = testDiv.cloneNode(true);
            testContainer.appendChild(clonedDiv);
            // Apply tested font-family
            clonedDiv.style.fontFamily = "'" + fontFamiliesArray[i] + "', " + referenceFontFamily;
            clonedDiv._ff = fontFamiliesArray[i];
        }
        
        // Check if dimension of all divs changed immediately after applying font-family
        // maybe all fonts were already loaded so we don't need to poll and wait.
        testDivDimensions();
        
        // Check that there is at least one div, means at least one not loaded font.
        if (testContainer.childNodes.length) {
            // Poll div for their dimensions every tryIntervalMs.
            interval = window.setInterval(function() {
                // Loop through all divs and check if their dimensions changed.
                testDivDimensions();
                // If no divs remained, then all fonts loaded.
                // We also won't wait too much time, maybe some fonts are broken.
                if (testContainer.childNodes.length === 0 || tryCount === maxNumOfTries) {
                    // All fonts are loaded OR (maxNumOfTries * tryIntervalMs) ms passed.
                    finish();
                } else {
                    tryCount++;
                }
            }, tryIntervalMs);
        } else {
            // All fonts are loaded
            testContainer.parentNode.removeChild(testContainer);
            fontsLoadedCallback(null);
        }
    };

}).apply(context);

window.onFontsLoad(['Noto Sans', 'Title', 'Subtitle'], function (error) {
    document.body.classList.remove('loading');
    if (document.body.classList.length < 1) {
        document.body.removeAttribute('class');
    }
});