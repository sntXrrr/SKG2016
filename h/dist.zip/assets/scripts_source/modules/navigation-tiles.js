var modules = window.modules = window.modules || [];

modules.push(function () {

	var elements,
		selectors,
		methods,
		state,
		options;

	elements = {};
	selectors = {
		container: '.navigation-tiles.container',
		media: '.media.container'
	};
	methods = {};
	state = {};
	options = {
		packery: { 
			"itemSelector": ".unit",
			"columnWidth": ".masonry-sizer",
			"gutter": 0,
			transitionDuration: '10.4s',
			"isResizeBound": false
		}
	};

	methods.tile = {
		resizeHandler: function (input) {
			input.packeryInstance.layout();
		}
	};

	methods.init = function () {
		elements.window = window;
		elements.body = document.querySelector('body');
		elements.viewport = document.querySelector('.viewport');

		[].slice.call(elements.viewport.querySelectorAll(selectors.container + '[variant="auto"]')).forEach(function (container) {
			var element = container.querySelector(selectors.media);
			var pckry = Packery.data(element) || (new Packery( element, options.masonry));
			addResizeListener(container, function (event) {
				methods.tile.resizeHandler({
					element: element,
					packeryInstance: pckry
				});
			});
		});
	};

	// DOM ready
	$(function () {
		methods.init();
	});

	return {
		init: methods.init,
		selector: selectors.container
	};

}());