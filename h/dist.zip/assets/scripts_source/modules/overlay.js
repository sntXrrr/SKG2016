// temp way
$('body').on('toggle', '.overlay.container', function (event, options) {

	if (options && options.activate) {
		$('[name="' + options.activate + '"]', this).attr('state', 'active');
		this.setAttribute('state', 'active');
	} else {
		$('[state*="active"]', this).attr('state', '');
		this.setAttribute('state', '');
	}
});


$('body').on('click', '[toggle="overlay"]', function (event) {
	var options;

	event.preventDefault();

	if (this.name && $('.overlay [name="' + this.name + '"]').length) {
		options = {
			activate: this.name
		};
	}

	setTimeout(function () {
		$('.overlay').trigger('toggle', options);
	}, 0);
});

// DOM ready
$(function () {
	$('.overlay.container [state="active"]');
});