var modules = window.modules = window.modules || [];

modules.push(function () {

	var elements,
	selectors,
	methods,
	state,
	options;

	elements = {};
	selectors = {
		container: '.trigger.container',
		regular: '.regular',
		video: '.video',
		videoFrame: '.video iframe'
	};
	methods = {};
	state = {};
	options = {};

	methods.viewport = {
		scrollHandler: function (event) {
			window.clearTimeout(state.scrollTimeout);
			state.scrollTimeout = window.setTimeout(methods.viewport.scrollAction, 50);
		},
		scrollAction: function () {
			var active = elements.videoTriggers.filter(function () {

			});
			elements.videoTriggers
				.map(function (item) {
					return {
						'isVisisble': (methods.video.isInView(item, elements.viewport)),
						'isActive': (item.getAttribute('state') === 'active'),
						'element': item
					};
				});
		}
	};

	methods.video = {
		playerReadyHandler: function (event, options) {
			options.player.mute();
			options.player.playVideo();
		},
		playerChangeHandler: function (event, options) {
			if (event.data === 1 ) {
				methods.video.display(options.container);
			} else if (event.data === 0) {
				options.player.playVideo();
			}
		},
		isInView: function (element, viewport) {
			var rect = element.getBoundingClientRect();

			return (
				rect.top >= 20 &&
				rect.left >= 0 &&
				rect.bottom <= viewport.clientHeight &&
				rect.right <= viewport.clientWidth
			);
		},

		display: function (container) {
			container.querySelector(selectors.video).setAttribute('state', 'active');
			container.querySelector(selectors.regular).setAttribute('state', '');
		},
		remove: function (container) {
			container.querySelector(selectors.video).setAttribute('state', '');
			container.querySelector(selectors.regular).setAttribute('state', 'active');
		},
		init: function (container) {
			var element,
			player,
			api;

			element = container.querySelector(selectors.videoFrame);

			state.youtubeApiLoaded.then(function (YT) {
			
				state.count = state.count ? (state.count + 1) : 1;

				element.id = (new RegExp(/([a-z0-9]+)\?/gi)).exec(element.getAttribute('data-src'))[1] + state.count.toString();
				element.onload = function () {
					new YT.Player(element.id, {
						events: {
							'onReady': function (event) {
								player = event.target;

								methods.video.playerReadyHandler(event, {
									'container': container, 
									'element': element, 
									'player': player
								});
							},
							'onStateChange': function (event) {
								methods.video.playerChangeHandler(event, {
									'container': container, 
									'element': element, 
									'player': player
								});
							}
						}
					});
				};

				window.setTimeout(function () {
					element.src = element.getAttribute('data-src').replace(/[\n\r\s]/gm, "");
					element.removeAttribute('data-src');
				}, state.count * 1000);
			});
		}
	};


	methods.init = function () {
		elements.window = window;
		elements.body = document.querySelector('body');
		elements.viewport = document.querySelector('.viewport');

		elements.allTriggers = [].slice.call(elements.viewport.querySelectorAll(selectors.container));
		elements.videoTriggers = elements.allTriggers.filter(function (item) {
			return !!(item.querySelector(selectors.video));
		});

		// if there are any video's we'll need the Youtube Api,
		// make a promise
		if (elements.videoTriggers.length){
			state.youtubeApiLoaded = new Promise(function (resolve, reject) {
				if (window.YT && window.YT.Player) {
					resolve(window.YT);
				} else {
					var callback = function () {
						var existing = window.onYouTubeIframeAPIReady;

						if (typeof existing === 'function') {
							//existing();
						}
						resolve(window.YT);
					};
					window.onYouTubeIframeAPIReady = callback;

					elements.youtubeApiScript = document.createElement("script");
					elements.youtubeApiScript.setAttribute("src", "https://www.youtube.com/iframe_api");
					elements.youtubeApiScript.setAttribute("async", "async");
					document.head.appendChild(elements.youtubeApiScript);
				}
			});

			//$(elements.window).on('scroll', methods.viewport.scrollHandler);
		}

		elements.videoTriggers.forEach(function (container) {
			methods.video.init(container);
		});
	};

	// DOM ready
	$(function () {
		methods.init();
	});

	return {
		init: methods.init,
		selector: selectors.container
	};

}());