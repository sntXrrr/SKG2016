(function () {

	var elements,
		methods,
		state;

	elements = {};
	methods = {};
	state = {};

	methods.countryselector = {
		selectChangeHandler: function (event) {
			elements.countryselector_text.value = elements.countryselector_select.options[elements.countryselector_select.selectedIndex].text;
			methods.countryselector.testValues();
			methods.applyState();
		},
		changeHandler: function (event) {
			if (methods.countryselector.testValues()) {
				elements.countryselector_select.value = elements.countryselector_select.querySelector('[title="' + elements.countryselector_text.value + '"]').value;
			}
			methods.applyState();
		},
		clearHandler: function (event) {
			event.preventDefault();
			elements.countryselector_text.value = "";
			elements.countryselector_text.focus();
			methods.countryselector.testValues();
			methods.applyState();
		},
		testValues: function () {
			var valueExists;

			valueExists = !!(elements.countryselector_select.querySelector('[title="' + elements.countryselector_text.value + '"]'));
			state.country_state = (valueExists ? "valid" : "invalid");
			elements.countryselector_text.setAttribute('state', state.country_state);

			return (state.country_state === "valid");
		},
		applySelect: function () {
			var value = elements.countryselector_select.querySelector('[title="' + elements.countryselector_text.value + '"]').value;
			elements.countryselector_select.value = value;
		}
	};

	methods.dateselector = {
		fullChangeHandler: function (event) {
			var date = methods.dateselector.convertFullToSeperated(elements.dateselector_fullDate.value);

			elements.dateselector_day.value = date.day;
			elements.dateselector_month.value = date.month;
			elements.dateselector_year.value = date.year.toString().slice(-2);
		},
		changeHandler: function (event) {
			methods.dateselector.testValues();
			methods.applyState();
		},
		testValues: function (event) {
			state.age = {
				day: elements.dateselector_day.value,
				month: elements.dateselector_month.value,
				year: elements.dateselector_year.value
			};

			if (state.age.day && state.age.month && state.age.year) {
				if (methods.dateselector.testDate(state.age)) {
					state.age_state = "valid";
				} else {
					state.age_state = "invalid";
				}
			} else if (state.age.day || state.age.month || state.age.year) {
				state.age_state = "progress";
			} else {
				state.age_state = "initial";
			}

			return (state.age_state === "valid");
		},

		testFullDateSupport: function () {
			return (elements.dateselector_fullDate.type === 'date');
		},
		testDate: function (date) {
			var temp;
			var currentYear = (new Date()).getFullYear();

			date.day = parseInt(date.day, 10);
			date.month = parseInt(date.month, 10) - 1;
			date.year = parseInt(date.year, 10) + (date.year > currentYear.toString().slice(-2) ? 1900 : 2000);

			temp = new Date(date.year, date.month, date.day);

			if (temp.getDate() === date.day && temp.getMonth() === date.month && temp.getFullYear() === date.year) {
				return true;
			} else {
				return false;
			}
		},

		convertFullToSeperated: function (value) {
			value = new Date(value);
			return {
				day: value.getDate(),
				month: value.getMonth() + 1,
				year: value.getFullYear()
			};
		}
	};

	methods.connect = {
		clickHandler: function (event) {
			event.preventDefault();

			var element = event.currentTarget;
			var network = (element.href.match(/#\!(.*)/)[1]);

			element.setAttribute('state', 'active');

			hello.login(network)
				.then(function () {
					return hello(network).api('/me').then(methods.connect.successHandler);
				})
				.then(null, function (error) {
					element.setAttribute('state', 'failed');
					methods.connect.errorHandler(error);
				});
		},

		errorHandler: function (error) {
			console.error(error);
		},
		successHandler: function (data) {
			var date;

			if (data && typeof data.birthday === "string") {
				date = data.birthday.split('/').map(function (item) {
					return parseInt(item, 10);
				});
				elements.dateselector_day.value = date[1];
				elements.dateselector_month.value = date[0];
				elements.dateselector_year.value = (date[2] > 1999 ? (date[2] - 2000) : (date[2] - 1900));

				elements.ageform.submit();
			} else {
				throw new Error("no birthday in data");
			}
		}
	};

	methods.form = {
		submitHandler: function (event) {
			var valid;

			valid = true;

			if (methods.countryselector.testValues() && methods.dateselector.testValues()) {
				elements.submitbutton.disabled = true;
			} else if (event) {
				event.preventDefault();
			}
		}
	};

	methods.applyState = function (input) {
		if (input) {
			elements.ageform.setAttribute('state', input);
		} else {
			methods.countryselector.testValues();
			methods.dateselector.testValues();

			if (state.age_state === "valid" && state.country_state === "valid") {
				elements.ageform.setAttribute('state', "valid");
			} else if (state.age_state === "valid" && state.country_state === "invalid") {
				elements.ageform.setAttribute('state', "invalid");
			} else {
				elements.ageform.setAttribute('state', state.age_state);
			}
		}
	};

	methods.init = function () {
		elements.window = window;
		elements.body = document.querySelector('body');
		elements.viewport = document.querySelector('.viewport');

		elements.ageform = document.querySelector('.form[variant="age"]');
		elements.submitbutton = elements.ageform.querySelector('.button[type="submit"]');

		elements.countryselector_container =	elements.ageform.querySelector('.input.container[variant="country"]');
		elements.countryselector_select =		elements.countryselector_container.querySelector('select');
		elements.countryselector_text =			elements.countryselector_container.querySelector('input.input.unit');
		elements.countryselector_clearButton =	elements.countryselector_container.querySelector('.clear');

		elements.dateselector_container =		elements.ageform.querySelector('.input.container[variant="date"]');
		elements.dateselector_day =			elements.dateselector_container.querySelector('.input.unit[variant*="day"]');
		elements.dateselector_month =			elements.dateselector_container.querySelector('.input.unit[variant*="month"]');
		elements.dateselector_year =			elements.dateselector_container.querySelector('.input.unit[variant*="year"]');
		elements.dateselector_fullDate =		elements.dateselector_container.querySelector('.input.unit[variant*="full"]');

		elements.connectform = 		document.querySelector('.form[variant="connect"]');
		elements.connect_buttons = 	[].slice.call(elements.connectform.querySelectorAll('.button'));

		state.fullDateSupport = methods.dateselector.testFullDateSupport();
		state.isMobile = (elements.window.innerWidth < 700);

		if (elements.dateselector_fullDate && state.fullDateSupport && state.isMobile) {
			elements.dateselector_fullDate.setAttribute('state', 'active');
			$(elements.dateselector_fullDate).on('change', methods.dateselector.fullChangeHandler);
		}

		$([elements.dateselector_day, elements.dateselector_month, elements.dateselector_year]).on('change keyup', methods.dateselector.changeHandler);

		$(elements.countryselector_text).on('change keyup datalist-selectcomplete', methods.countryselector.changeHandler);
		$(elements.countryselector_select).on('change', methods.countryselector.selectChangeHandler);
		$(elements.countryselector_clearButton).on('click', methods.countryselector.clearHandler);

		$(elements.connect_buttons).on('click', methods.connect.clickHandler);

		$(elements.ageform).on('submit', methods.form.submitHandler);

		methods.applyState('initial');
		methods.countryselector.selectChangeHandler();

		hello.init({ 
			facebook: '794138907302337'
		}, {
			redirect_uri: 'http://scheineken.local/gateway'
		});
	};

	// DOM ready
	$(function () {
		methods.init();
	});
}());