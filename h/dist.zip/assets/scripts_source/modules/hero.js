(function () {

	var elements,
		methods,
		callbacks,
		state;

	elements = {};
	methods = {};
	callbacks = {
		"in": [],
		"within": [],
		"out": []
	};
	state = {};

	methods.test_scrolltop = function () {
		state.scrollTop = elements.viewport.pageYOffset;
		if (state.scrollTop < 320) {
			methods.applyWithin();
			if (state.isFull) {
				methods.applyIn();
				state.isFull = false;
			}
		} else if (!state.isFull) {
			state.isFull = true;
			methods.applyOut();
		}
	};

	methods.applyIn = function () {
		if (callbacks["in"].length) {
			callbacks["in"].forEach(function (item) {
				item();
			});
		}
	};
	methods.applyWithin = function () {
		if (callbacks["within"].length) {
			callbacks["within"].forEach(function (item) {
				item();
			});
		}
	};
	methods.applyOut = function () {
		if (callbacks["out"].length) {
			callbacks["out"].forEach(function (item) {
				item();
			});
		}
	};

	methods.image = {
		applyOpacity: function (opacity) {
			elements.blurredBackground.style.opacity = opacity;
		},
		init: function () {
			state.hasScrollBinding = true;

			callbacks["within"].push(function () {
				methods.image.applyOpacity(state.scrollTop / 320);
			});
			callbacks["out"].push(function () {
				methods.image.applyOpacity(1);
			});
		}
	};

	methods.video = {
		onApiReady: function () {
			state.youtubeApiLoaded = "done";

			elements.videoIframe.id = (new RegExp(/([a-z0-9]+)\?/gi)).exec(elements.videoIframe.getAttribute('data-src'))[1];
			elements.videoIframe.src = elements.videoIframe.getAttribute('data-src');

			new YT.Player(elements.videoIframe.id, {
				events: {
					'onReady': methods.video.onPlayerReady,
					'onStateChange': methods.video.onPlayerStateChange
				}
			});
		},
		onPlayerReady: function (event) {
			elements.videoElement = event.target;
			elements.videoElement.mute();

			callbacks["in"].push(function () {
				methods.video.play();
			});
			callbacks["out"].push(function () {
				methods.video.pause();
			});

			if (state.isFull) {
				methods.video.pause();
			}
		},
		onPlayerStateChange: function (event) {
			if (event.data === 1 ) {
				methods.video.display();
			} else if (event.data === 0) {
				methods.video.play();
			}
		},

		display: function () {
			elements.videoBackground.setAttribute('state', 'active');
			elements.regularBackground.setAttribute('state', '');
		},
		play: function () {
			elements.videoElement.playVideo();
		},
		pause: function () {
			elements.videoElement.pauseVideo();
		},
		init: function () {
			state.hasScrollBinding = true;

			elements.videoIframe = elements.videoBackground.querySelector('iframe');

			if (state.youtubeApiLoaded === "done") {
				methods.video.onApiReady();
			} else if (state.youtubeApiLoaded === "pending") {
				//TODO
			} else {
				state.youtubeApiLoaded = "pending";

				window.onYouTubeIframeAPIReady = methods.video.onApiReady;
				$('<script src="https://www.youtube.com/iframe_api"></script>').appendTo('body');
			}
		}
	};

	methods.init = function () {
		elements.viewport = window;
		elements.hero = $('.hero')[0];
		elements.regularBackground = $('.background.regular', elements.hero)[0];
		elements.blurredBackground = $('.background.blurred', elements.hero)[0];
		elements.videoBackground = $('.background.video', elements.hero)[0];

		if (elements.blurredBackground) {
			methods.image.init();
		}

		if (elements.videoBackground) {
			methods.video.init();
		}

		if (state.hasScrollBinding) {
			$(elements.viewport).on('scroll', methods.test_scrolltop);
			methods.test_scrolltop();
		}
	};

	// DOM ready
	$(function () {
		if ($('.hero').length) {
			methods.init();
		}
	});

}());