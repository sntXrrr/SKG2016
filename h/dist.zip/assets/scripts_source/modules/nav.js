(function () {

	var elements,
		methods,
		state;

	elements = {};
	methods = {};
	state = {
		isFull: true
	};

	methods.expander = {
		clickHandler: function (event) {
			var menu,
				li;

			li = event.currentTarget.parentNode;
			menu = li.querySelector('.menu');

			event.preventDefault();

			if (!menu.style.maxHeight) {
				menu.style.maxHeight = (menu.scrollHeight + 'px');
			}

			$(li).siblings('[state*="active"]').each(methods.expander.removeActiveState);
			if ((li.getAttribute('state') || '').match(/(active)/)) {
				methods.expander.removeActiveState(li);
			} else {
				methods.expander.applyActiveState(li);
			}
		},
		applyActiveState: function (element) {
			element.setAttribute('state', ((element.getAttribute('state') || '') + ' active').replace('  ', ' ').trim());
		},
		removeActiveState: function (element) {
			if (typeof arguments[0] === 'number') {
				element = arguments[1];
			}
			element.setAttribute('state', (element.getAttribute('state') || '').replace(/(active)/gi, '').replace('  ', ' ').trim());
		}
	};

	methods.viewport = {
		scrollHandler: function () {
			if (state.active === elements.topnav) {

				state.wasUp = state.isUp;
				state.wasDown = state.isDown;
				state.wasFull = state.isFull;

				state.isUp = (state.scrollTop > elements.window.pageYOffset);
				state.isDown = !state.isUp;
				state.isFull = (elements.window.pageYOffset < 200);

				state.scrollTop = elements.window.pageYOffset;

				if (state.isFull && !state.wasFull) {
					methods.nav.removeUpDownState(elements.topnav);
					methods.viewport.applyActiveState();
				} else if (!state.isFull) {
					if (state.wasDown && state.isUp) {
						methods.nav.applyUpState(elements.topnav);
						methods.viewport.applyActiveState();
					} else if ((state.wasFull) || (state.wasUp && state.isDown)) {
						methods.nav.applyDownState(elements.topnav);
						methods.viewport.applyActiveState();
					}
				}
			}
		},
		resizeHandler: function () {
			state.isMobile = (elements.window.innerWidth < 700);

			if (state.isMobile) {
				if (elements.sidenav && state.active === elements.sidenav) {
					methods.nav.removeActiveState(elements.sidenav);
				}
				if (state.active !== elements.topnav) {
					state.active = elements.topnav;
					methods.nav.applyActiveState(elements.topnav);
				}
			} else {
				if (elements.sidenav) {
					if (state.active !== elements.sidenav) {
						state.active = elements.sidenav;
						methods.nav.applyActiveState(elements.sidenav);
						methods.nav.removeActiveState(elements.topnav);
					}
				} else {
					if (state.active !== elements.topnav) {
						state.active = elements.topnav;
						methods.nav.applyActiveState(elements.topnav);
					}
				}
			}
		},

		applyActiveState: function () {
			if (state.active === elements.sidenav) {
				state.viewportState = 'pushed-right';
			} else if (state.active === elements.topnav) {
				if (!state.isFull) {
					state.viewportState = 'pushed-down-null';
				} else if (state.hasSubmenu) {
					state.viewportState = 'pushed-down-extra';
				} else {
					state.viewportState = 'pushed-down';
				}
			} else if (state.active === elements.mobilenav) {
				state.viewportState = 'pushed-left';
			} else {
				state.viewportState = '';
			}

			elements.viewport.setAttribute('state', state.viewportState);
		},
		removeActiveState: function () {
			elements.viewport.setAttribute('state', '');
		}
	};

	methods.nav = {
		applyActiveState: function (element) {
			state.active = element;
			methods.viewport.applyActiveState();
			element.setAttribute('state', ((element.getAttribute('state') || '') + ' active').replace('  ', ' ').trim());

		},
		removeActiveState: function (element) {
			if (typeof arguments[0] === 'number') {
				element = arguments[1];
			}
			element.setAttribute('state', (element.getAttribute('state') || '').replace(/(active)/gi, '').replace('  ', ' ').trim());
		},

		applyUpState: function (element) {
			methods.nav.removeUpDownState(element);
			element.setAttribute('state', (element.getAttribute('state') || '') + ' up');
		},
		applyDownState: function (element) {
			methods.nav.removeUpDownState(element);
			element.setAttribute('state', (element.getAttribute('state') || '') + ' down');
		},
		removeUpDownState: function (element) {
			element.setAttribute('state', (element.getAttribute('state') || '').replace(/(up|down)/gi, '').replace('  ', ' ').trim());
		},

		mobileNavToggleHandler: function (event) {
			if (state.isMobile) {
				event.preventDefault();

				if (state.active === elements.mobilenav) {
					state.active = elements.topnav;
					methods.nav.applyActiveState(elements.topnav);
					methods.nav.removeActiveState(elements.mobilenav);
				} else {
					methods.nav.applyActiveState(elements.mobilenav);
				}
			}
		}
	};

	methods.init = function () {
		elements.window = window;
		elements.body = $('body')[0];
		elements.viewport = $('.viewport')[0];
		
		elements.topnav = $('.nav[variant*="top"]')[0];
		elements.sidenav = $('.nav[variant*="side"]')[0];
		elements.mobilenav = $('.nav[variant*="mobile"]')[0];

		if (elements.topnav) {
			state.hasSubmenu = !!((elements.topnav.getAttribute('variant') || '').match(/(sub)/));
			$(elements.window).on('scroll', methods.viewport.scrollHandler);
		}

		$(elements.window).on('resize orientationchange', methods.viewport.resizeHandler);

		if (elements.mobilenav) {
			$(elements.mobilenav).on('click', 'li:has(>.menu) > a', methods.expander.clickHandler);
			$(elements.body).on('click', '[toggle="nav"]', methods.nav.mobileNavToggleHandler);

			$(document).ready(function(){
				$('.carousel').carousel({
					slidesToShow: 2,
					slidesToScroll: 2,
					dots: true,
					arrows: false,
					infinite: false
				});
			});
		}

		methods.viewport.scrollHandler();
		methods.viewport.resizeHandler();
	};

	// DOM ready
	$(function () {
		methods.init();
	});

}());