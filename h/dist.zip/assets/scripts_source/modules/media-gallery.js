(function () {

	var elements,
		methods,
		state;

	elements = {};
	methods = {};
	state = {
		variant: undefined
	};

	methods.viewport = {
		resizeHandler: function () {
			state.isMobile = (elements.window.innerWidth < 700);
			methods.gallery.testVariant();

			if (state.variant === 'slides') {
				elements.galleries.forEach(methods.gallery.reposition);
			}
		}
	};

	methods.drag = {
		moveHandler: function (event) {
			if (!state.isMobile && state.scrollElement && (event.originalEvent.screenX || event.originalEvent.touches[0].screenX)) {

				state.scrollXPosition = event.originalEvent.screenX || event.originalEvent.touches[0].screenX;
				state.scrollYPosition = event.originalEvent.screenY || event.originalEvent.touches[0].screenY;
				
				state.scrollXDelta = state.scrollXBase - state.scrollXPosition;
				state.scrollYDelta = state.scrollYBase - state.scrollYPosition;

				if (!state.isScrolling && state.scrollXDelta !== 0) {
					state.isScrolling = true;					
				}

				if (Math.abs(state.scrollXDelta) > Math.abs(state.scrollYDelta)) {
					event.preventDefault();

					var element = event.originalEvent.currentTarget;

					state.scrollXBase = (event.originalEvent.screenX || event.originalEvent.touches[0].screenX);
					state.scrollYBase = (event.originalEvent.screenY || event.originalEvent.touches[0].screenY);

					state.scrollElement.scrollLeft = state.scrollElement.scrollLeft + state.scrollXDelta;
				}
			}
		},
		startHandler: function (event) {
			if (!state.isMobile) {

				state.scrollXBase = (event.originalEvent.screenX || event.originalEvent.touches[0].screenX);
				state.scrollYBase = (event.originalEvent.screenY || event.originalEvent.touches[0].screenY);

				state.scrollXDelta = 0;
				state.scrollYDelta = 0;

				state.scrollElement = event.originalEvent.currentTarget.querySelector('.media-gallery.unit');
			}
		},
		endHandler: function (event) {
			if (!state.isMobile && state.isScrolling) {
				methods.gallery.moveTo(methods.gallery.determinSlide({
					element: state.scrollElement,
					direction: ((state.scrollXDelta < 0) ? 'left' : 'right')
				}));
			}
			setTimeout(function () {
				state.isScrolling = false;
				state.scrollElement = undefined;
				state.scrollDelta = 0;
			}, 12);
		},

		preventDefault: function (event) {
			event.preventDefault();
		}
	};

	methods.media = {
		clickHandler: function (event) {
			if (state.isScrolling) {
				event.preventDefault();
			}
		},
		activate: function (element) {
			[].slice.call(element.parentElement.querySelectorAll('[state]')).forEach(function (item) {
				item.removeAttribute('state');
			});
			element.setAttribute('state', 'active');
		},
		highlite: function (element) {
			[].slice.call(element.parentElement.querySelectorAll('[state]')).forEach(function (item) {
				if (item.getAttribute('state') === 'active') {
					item.setAttribute('state', 'faded');
				} else {
					item.removeAttribute('state');
				}
			});
			
			if (!element.getAttribute('state')) {
				element.setAttribute('state', 'highlite');
			}
		}
	};

	methods.tool = {
		clickHandler: function (event) {
			var gallery = event.originalEvent.currentTarget.querySelector('.media-gallery.unit');
			methods.gallery.moveTo(methods.gallery.determinSlide({
				element: gallery,
				direction: 'right'
			}));
		},
		hoverHandler: function (event) {
			var gallery = event.delegateTarget.querySelector('.media-gallery.unit');
			if (event.type === "mouseenter") {
				methods.media.highlite(methods.gallery.determinSlide({
					element: gallery,
					reach: 1.2,
					direction: (event.currentTarget.href.match(/#\!(.*)/)[1])
				}));
			} else {
				methods.media.activate(methods.gallery.determinSlide({
					element: gallery,
					reach: 0.5,
					direction: (event.currentTarget.href.match(/#\!(.*)/)[1])
				}));
			}
		},

		setCounter: function (options) {
			options.element.querySelector('.tool.counter [output="index"]').innerText = options.index;
		}
	};

	methods.gallery = {
		moveTo: function (element) {
			if (element && element.parentElement) {
				$(element.parentElement).animate({
					scrollLeft: element.offsetLeft
				});

				methods.media.activate(element);

				methods.tool.setCounter({
					element: element.parentElement.parentElement,
					index: ([].indexOf.call(element.parentElement.children, element) + 1)
				});
			}
		},
		determinSlide: function (options) {
			var galleryBounds = options.element.getBoundingClientRect();
			var slides = [].slice.call(options.element.querySelectorAll('.media.container')).filter(function (item) {
				var bounds = item.getBoundingClientRect();

				if (Math.abs(bounds.left) <= (galleryBounds.width * (options.reach || 1.2))) {
					return true;
				} else {
					return false;
				}
			});

			if (options.direction === 'left') {
				return slides[0];
			} else {
				return slides[slides.length - 1];
			}
		},
		reposition: function (gallery) {
			methods.gallery.moveTo(methods.gallery.determinSlide({
				element: gallery,
				direction: 'left'
			}));
		},

		testVariant: function () {
			if (state.isMobile && (state.variant === "slides" || state.variant === undefined)) {
				methods.gallery.switchVariant("scroll");
			} else if (!state.isMobile && (state.variant === "scroll" || state.variant === undefined)) {
				methods.gallery.switchVariant("slides");
			} 
		},
		switchVariant: function (variant) {
			state.variant = variant;
			elements.galleries.forEach(function (item) {
				item.setAttribute('variant', variant);
			});
		}
	};

	methods.init = function () {
		elements.window = window;
		elements.body = document.querySelector('body');
		elements.viewport = document.querySelector('.viewport');

		elements.galleries = [].slice.call(document.querySelectorAll('.media-gallery.container'));

		$(elements.galleries).on('touchstart mousedown', methods.drag.startHandler);
		$(elements.galleries).on('touchmove mousemove', methods.drag.moveHandler);
		$(elements.body).on('touchend mouseup', methods.drag.endHandler);
		$(elements.galleries).on('dragstart select', methods.drag.preventDefault);

		$(elements.galleries).on('click', '.media.unit', methods.media.clickHandler);
		$(elements.galleries).on('click', '.tool.button', methods.tool.clickHandler);
		$(elements.galleries).on('mouseenter mouseleave', '.tool.button', methods.tool.hoverHandler);

		$(elements.window).on('resize orientationchange', methods.viewport.resizeHandler);
		methods.viewport.resizeHandler();
	};

	// DOM ready
	$(function () {
		methods.init();
	});

}());