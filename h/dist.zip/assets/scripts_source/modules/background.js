var modules = window.modules = window.modules || [];

modules.push(function () {

	var elements,
		selectors,
		methods,
		state,
		options;

	elements = {};
	selectors = {
		container: '.background.container',
		unit: '.background.unit',

		regular: '.regular',
		blurred: '.blurred'
	};
	methods = {};
	state = {};
	options = {};

	methods.blur = function (container) {
		container.querySelector(selectors.regular).setAttribute('state', '');
		container.querySelector(selectors.blurred).setAttribute('state', 'active');
	};

	methods.init = function (options) {
		options = options || {};

		elements.window = window;
		elements.body = document.querySelector('body');
		elements.viewport = options.viewport || document.querySelector('.viewport');

		[].slice.call(elements.viewport.querySelectorAll(selectors.container)).forEach(methods.blur);
	};

	// DOM ready
	$(function () {
		methods.init();
	});

	return {
		init: methods.init,
		selector: selectors.container
	};

}());